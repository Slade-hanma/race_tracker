import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'Screen/Authentication.dart';
import '../provider/selection_provider.dart';
import 'provider/stopwatch_provider.dart';
import '../provider/participant_provider.dart';
import '../provider/result_provider.dart';
import '../provider/race_provider.dart';
import '../provider/race_status_provider.dart';

import 'repository/Mock_Repo/mock_swatch_repo.dart';
import 'repository/Mock_Repo/mock_participant_repo.dart';
import 'repository/Mock_Repo/mock_race_repo.dart';
import 'repository/Mock_Repo/mock_result_repo.dart';
import 'repository/Mock_Repo/mock_race_status_repo.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ParticipantProvider(MockParticipantRepo())),
        ChangeNotifierProvider(create: (_) => RaceProvider(MockRaceRepo())),
        ChangeNotifierProvider(create: (_) => ResultProvider(MockResultRepo())),
        ChangeNotifierProvider(create: (_) => SelectionProvider()),
        ChangeNotifierProvider(create: (_) => RaceStatusProvider(MockRaceStatusRepo())),
        ChangeNotifierProvider(create: (_) => StopwatchProvider(MockSwatchRepo())),
      ],
      child:  MyApp(),
    ),
    );  
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: AuthenticationScreen(),
      ),
    );
  }
}