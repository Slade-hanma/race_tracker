import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../model/participant_model.dart';
import '../../../provider/participant_provider.dart';

class ParticipantProfileScreen extends StatefulWidget {
  final Participant participant;

  const ParticipantProfileScreen({Key? key, required this.participant}) : super(key: key);

  @override
  State<ParticipantProfileScreen> createState() => _ParticipantProfileScreenState();
}

class _ParticipantProfileScreenState extends State<ParticipantProfileScreen> {
  bool isEditing = false;
  late TextEditingController nameController;
  late TextEditingController sexController;
  late TextEditingController dobController;
  late TextEditingController schoolController;
  late TextEditingController bibNumberController;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.participant.name);
    sexController = TextEditingController(text: widget.participant.sex);
    dobController = TextEditingController(text: widget.participant.dateOfBirth.toIso8601String().split('T')[0]); // YYYY-MM-DD
    schoolController = TextEditingController(text: widget.participant.school);
    bibNumberController = TextEditingController(text: widget.participant.bibNumber);
  }

  @override
  void dispose() {
    nameController.dispose();
    sexController.dispose();
    dobController.dispose();
    schoolController.dispose();
    bibNumberController.dispose();
    super.dispose();
  }

  void toggleEdit() {
    setState(() {
      isEditing = !isEditing;
    });
  }

  void updateParticipant() {
    final updatedParticipant = Participant(
      id: widget.participant.id,
      name: nameController.text,
      sex: sexController.text,
      dateOfBirth: DateTime.tryParse(dobController.text) ?? widget.participant.dateOfBirth,
      school: schoolController.text,
      bibNumber: bibNumberController.text,
    );

    Provider.of<ParticipantProvider>(context, listen: false).updateParticipant(updatedParticipant);

    setState(() {
      isEditing = false;
    });

    // Pop and return updated participant to previous screen if needed
    Navigator.pop(context, updatedParticipant);
  }

  Widget buildTextField(String label, TextEditingController controller, {bool enabled = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        enabled: enabled,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Info' : 'Profile'),
        leading: BackButton(),
        actions: [
          TextButton(
            onPressed: toggleEdit,
            child: Text(
              isEditing ? 'Cancel' : 'Edit',
              style: TextStyle(color: Colors.white),
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            buildTextField('Name', nameController, enabled: isEditing),
            buildTextField('Sex', sexController, enabled: isEditing),
            buildTextField('Date of Birth (YYYY-MM-DD)', dobController, enabled: isEditing),
            buildTextField('School', schoolController, enabled: isEditing),
            buildTextField('Bib Number', bibNumberController, enabled: isEditing),
            if (isEditing)
              ElevatedButton(
                onPressed: updateParticipant,
                child: Text('Update'),
              ),
          ],
        ),
      ),
    );
  }
}
