// lib/participant_form.dart
import 'package:flutter/material.dart';
import '../../../model/participant_model.dart';
import '../../../provider/participant_provider.dart';

class ParticipantForm extends StatefulWidget {
  final Function(Participant) onSubmit;
  final ParticipantProvider participantProvider;

  ParticipantForm({Key? key, required this.onSubmit, required this.participantProvider}) : super(key: key);

  @override
  _ParticipantFormState createState() => _ParticipantFormState();
}

class _ParticipantFormState extends State<ParticipantForm> {
  final _formKey = GlobalKey<FormState>();
  String name = '';
  String sex = '';
  DateTime dateOfBirth = DateTime.now();
  String school = '';
  String bibNumber = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            TextFormField(
              decoration: InputDecoration(labelText: 'Name'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your name';
                }
                return null;
              },
              onSaved: (value) {
                name = value!;
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Sex'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your sex';
                }
                return null;
              },
              onSaved: (value) {
                sex = value!;
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Date of Birth'),
              onTap: () async {
                FocusScope.of(context).requestFocus(FocusNode());
                DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: dateOfBirth,
                  firstDate: DateTime(1900),
                  lastDate: DateTime.now(),
                );
                if (pickedDate != null) {
                  setState(() {
                    dateOfBirth = pickedDate;
                  });
                }
              },
              readOnly: true,
              validator: (value) {
                if (dateOfBirth == DateTime.now()) {
                  return 'Please select your date of birth';
                }
                return null;
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'School'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your school';
                }
                return null;
              },
              onSaved: (value) {
                school = value!;
              },
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Bib Number'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your bib number';
                }
                return null;
              },
              onSaved: (value) {
                bibNumber = value!;
              },
            ),
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  Participant newParticipant = Participant(
                    id: widget.participantProvider.getNextId(),
                    name: name,
                    sex: sex,
                    dateOfBirth: dateOfBirth,
                    school: school,
                    bibNumber: bibNumber,
                  );

                  // Call the onSubmit callback
                  widget.onSubmit(newParticipant);

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Participant added!')),
                  );

                  _formKey.currentState!.reset();
                  setState(() {
                    dateOfBirth = DateTime.now(); 
                  });

                  // Navigate back to ListScreen
                  Navigator.pop(context);
                }
              },
              child: Text('Add Participant'),
            ),
          ],
        ),
      ),
    );
  }
}
