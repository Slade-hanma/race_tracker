// import 'package:flutter/material.dart';
// import 'package:race_tack_with_provider/model/participant_model.dart';
// import 'participant_card.dart';
// import '../repository/mock_participant_repo.dart';
// import 'participantform.dart';

// class ListScreen extends StatelessWidget {
//   ListScreen({Key? key}) : super(key: key);
//   //if want to use repository implement like, but should have abstract file for repository blue
//   final MockParticipantRepo repository = MockParticipantRepo();
  
//   @override
//   Widget build(BuildContext context) {
//     //after access it like this
//     final List<Participant> participants = repository.getParticipants();
//     return Scaffold(
//       appBar: AppBar(title: const Text("Participants")),
//       body: Container(
        
//         child: Column(
//            children: [
//             Expanded(
//               child: ListView.builder(
//                 itemCount: participants.length,
//                 itemBuilder: (context, index) {
//                   return ParticipantCard(participant: participants[index]);
//                 }
//               ),
//             ),
//             ElevatedButton(
//             onPressed: () {
//               // Navigate to ParticipantForm
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => ParticipantForm(repo: repository),
//                 ),
//               );
//             },
//             child: Text('Add New Participant'),
//           ),
//            ],
//         )
//       ),
//     );
//   }
// }


import 'dart:async';

import 'package:flutter/material.dart';
import '../../model/participant_model.dart';
import 'widgets/participant_card.dart';
import 'widgets/participantform.dart'; // Import your ParticipantForm
import '../../provider/participant_provider.dart';
import 'package:provider/provider.dart';
import 'widgets/participant_profile.dart';


class ListScreen extends StatefulWidget {
  @override
  _ListScreenState createState() => _ListScreenState();
}

class _ListScreenState extends State<ListScreen> {

    final Map<int, Timer> _deletionTimers = {}; // Stores timers for scheduled deletions
  final Set<int> _pendingDeletions = {}; // Track temporarily removed participants by ID

  void _confirmDelete(BuildContext context, Participant participant, ParticipantProvider provider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Delete Participant"),
        content: Text("Are you sure you want to delete this participant?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _scheduleDelete(context, participant, provider);
            },
            child: Text("Delete", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _scheduleDelete(BuildContext context, Participant participant, ParticipantProvider provider) {
    setState(() {
      _pendingDeletions.add(participant.id);
    });

    final timer = Timer(Duration(seconds: 24), () {
      provider.deleteParticipant(participant.id.toString());
      setState(() {
        _pendingDeletions.remove(participant.id);
        _deletionTimers.remove(participant.id);
      });
    });

    _deletionTimers[participant.id] = timer;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Participant will be deleted in 24 seconds"),
        duration: Duration(seconds: 24),
        action: SnackBarAction(
          label: "UNDO",
          onPressed: () {
            timer.cancel();
            setState(() {
              _pendingDeletions.remove(participant.id);
              _deletionTimers.remove(participant.id);
            });
          },
        ),
      ),
    );
  }

  @override
  void dispose() {
    for (var timer in _deletionTimers.values) {
      timer.cancel();
    }
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    final participantProvider = Provider.of<ParticipantProvider>(context);
    final visibleParticipants = participantProvider.participants
        .where((p) => !_pendingDeletions.contains(p.id))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Participants"),
        // actions: [
        //   IconButton(
        //     icon: Icon(Icons.add),
        //     onPressed: () {
        //       // Show dialog to add a new participant
        //       showDialog(
        //         context: context,
        //         builder: (context) => AlertDialog(
        //           title: Text('Add Participant'),
        //           content: ParticipantForm(
        //             repo: repository,
        //             onSubmit: _addParticipant, // Pass the function to handle submission
        //           ),
        //         ),
        //       );
        //     },
        //   ),
        // ],
      ),
      body: Column(
        children: [
          ElevatedButton(
            onPressed: () {
              // Navigate to ParticipantForm
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ParticipantForm(
                    onSubmit: participantProvider.addParticipant,
                    participantProvider: participantProvider,
                  ),
                ),
              );
            },
            child: Text('Add New Participant'),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: visibleParticipants.length,
              itemBuilder: (context, index) {
                 final participant = visibleParticipants[index];

                return Dismissible(
                  key: Key(participant.id.toString()),
                  direction: DismissDirection.endToStart,
                  confirmDismiss: (_) async {
                    _confirmDelete(context, participant, participantProvider);
                    return false;
                  },
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Icon(Icons.delete, color: Colors.white),
                  ),
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ParticipantProfileScreen(participant: participant),
                        ),
                      );
                    },
                    child: ParticipantCard(participant: participant),
                  ));
              },
            ),
          ),
        ],
      ),
    );
  }
}
