import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/participant_list.dart';
import '../../provider/race_status_provider.dart';

class RaceStatusWidget extends StatelessWidget {
  final String raceName;
  final bool isManager;

  const RaceStatusWidget({Key? key, required this.raceName, required this.isManager}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final statusProvider = context.watch<RaceStatusProvider>();
    final currentStatus = statusProvider.getStatus(raceName);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: currentStatus.backgroundColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: isManager
          ? DropdownButtonHideUnderline(
              child: DropdownButton<RaceStatus>(
                value: currentStatus,
                dropdownColor: currentStatus.backgroundColor,
                iconEnabledColor: currentStatus.textColor,
                style: TextStyle(color: currentStatus.textColor),
                items: RaceStatus.values.map((status) {
                  return DropdownMenuItem(
                    value: status,
                    child: Text(status.label, style: TextStyle(color: status.textColor)),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) {
                    statusProvider.updateStatus(raceName, value);
                  }
                },
              ),
            )
          : Text(
              currentStatus.label,
              style: TextStyle(color: currentStatus.textColor, fontWeight: FontWeight.bold),
            ),
    );
  }
}