// screens/participant_tracking_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/participant_list.dart';
import '../../model/race_model.dart';
import 'widget/tracking_card.dart';
import 'widget/tracking_footer.dart';
import '../../provider/stopwatch_provider.dart'; 


class TrackingScreen extends StatelessWidget {
  final Race race;

  const TrackingScreen({Key? key, required this.race}) : super(key: key);

  @override
  Widget build(BuildContext context) {

        final stopwatchProvider = context.read<StopwatchProvider>();


    return Scaffold(
      appBar: AppBar(
        title: const Text("Tracking Participants"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(10),
              itemCount: participants.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 3 / 4,
              ),
              itemBuilder: (context, index) {
                return ParticipantTrackingCard(
                  participant: participants[index],
                  race: race,
                  stopwatchProvider: stopwatchProvider,

                );
              },
            ),
          ),
          SubmitFooter(stopwatchProvider: stopwatchProvider),
        ],
      ),
    );
  }
}
