// widgets/footer_widget.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../provider/result_provider.dart';
import '../../../provider/selection_provider.dart';
import '../../../provider/stopwatch_provider.dart';


class SubmitFooter extends StatelessWidget {
final StopwatchProvider stopwatchProvider;

  const SubmitFooter({Key? key, required this.stopwatchProvider}) : super(key: key);

  void submitAll(BuildContext context) {
    final selectionProvider = context.read<SelectionProvider>();
    final resultProvider = context.read<ResultProvider>();

    for (final result in selectionProvider.selectedResults) {
      resultProvider.addResult(result);
    }

    selectionProvider.clearSelections();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Submitted to result list")),
    );
  }

  @override
  Widget build(BuildContext context) {
    final selectedCount = context.watch<SelectionProvider>().selectedResults.length;
    final stopwatchTime = stopwatchProvider.displayTime;

    return Column(
      children: [
        if (selectedCount > 0)
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text("$selectedCount participants selected"),
          ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
           
              Text(
                stopwatchTime,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),

          
              ElevatedButton(
                onPressed: selectedCount > 0 ? () => submitAll(context) : null,
                child: const Text("Submit"),
              ),
            ],
          ),
        ),
      ],
    );
  }

}
