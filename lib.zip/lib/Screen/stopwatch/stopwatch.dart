// lib/stopwatch_widget.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'widgets/time_display.dart';
import 'widgets/start_button.dart';
import 'widgets/stop_button.dart';
import 'widgets/reset_button.dart';
import '../../provider/stopwatch_provider.dart'; 

class StopwatchWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final stopwatchProvider = context.watch<StopwatchProvider>();

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TimeDisplay(time: stopwatchProvider.displayTime),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
           
            if (!stopwatchProvider.isRunning)
              StartButton(onStart: () {
                stopwatchProvider.start();
              }),
       
            if (stopwatchProvider.isRunning) ...[
              StopButton(
                onStop: () => stopwatchProvider.stop(),
                buttonText: stopwatchProvider.stopButtonText,
              ),
              ResetButton(onReset: () {
                stopwatchProvider.reset();
              }),
            ],
          ],
        ),
      ],
    );
  }
}
