import 'package:flutter/material.dart';

class StartButton extends StatelessWidget {
  final VoidCallback onStart;

  const StartButton({Key? key, required this.onStart}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onStart,
      child: Text("Start"),
      style: ElevatedButton.styleFrom(
        textStyle: TextStyle(fontSize: 20), // Keep original style
      ),
    );
  }
}
