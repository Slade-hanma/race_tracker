import 'package:flutter/material.dart';

class StopButton extends StatelessWidget {
  final VoidCallback onStop;
  final String buttonText;

  const StopButton({
    Key? key,
    required this.onStop,
    required this.buttonText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onStop,
      child: Text(buttonText),
      style: ElevatedButton.styleFrom(
        textStyle: TextStyle(fontSize: 20),
      ),
    );
  }
}
