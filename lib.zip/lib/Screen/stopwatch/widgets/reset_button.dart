import 'package:flutter/material.dart';

class ResetButton extends StatelessWidget {
  final VoidCallback onReset;

  const ResetButton({Key? key, required this.onReset}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onReset,
      child: Text("Reset"),
      style: ElevatedButton.styleFrom(
        textStyle: TextStyle(fontSize: 20), // Keep original style
      ),
    );
  }
}
