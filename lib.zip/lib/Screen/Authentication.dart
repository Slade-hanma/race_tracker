import 'package:flutter/material.dart';
import 'Race/race_list_view.dart';

class AuthenticationScreen extends StatefulWidget {
  @override
  _AuthenticationScreenState createState() => _AuthenticationScreenState();
}

class _AuthenticationScreenState extends State<AuthenticationScreen> {
  bool? isManager;

  @override
  Widget build(BuildContext context) {
    if (isManager == null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Card(
                child: ListTile(
                  title: const Text("Race Manager"),
                  onTap: () {
                    setState(() {
                      isManager = true;
                    });
                  },
                ),
              ),
              Card(
                child: ListTile(
                  title: const Text("Race Tracker"),
                  onTap: () {
                    setState(() {
                      isManager = false;
                    });
                  },
                ),
              ),
            ],
          ),
        ),
      );
    } else {
      return Scaffold(
        appBar: AppBar(
          title: Text(isManager! ? "Race Manager" : "Race Tracker"),
          leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {setState(() {
          isManager = null; 
        });},
        ),
        ),
        body: RacesListView(isManager: isManager!),
      );
    }
  }
}
