// main.dart
import 'package:flutter/material.dart';
import '../provider/result_provider.dart';
import 'package:provider/provider.dart';

class ResultsListView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final results = Provider.of<ResultProvider>(context).results; // Access races from provider

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          // Header Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Expanded(child: Center(child: Text('Rank'))),
              Expanded(child: Center(child: Text('BIB'))),
              Expanded(child: Center(child: Text('Name'))),
              Expanded(child: Center(child: Text('Start Time'))),
              Expanded(child: Center(child: Text('Finish Time'))),
            ],
          ),
          Divider(),
          // Results List
          Expanded(
            child: ListView.builder(
              itemCount: results.length,
              itemBuilder: (context, index) {
                final result = results[index];
                return Container(
                  margin: const EdgeInsets.symmetric(vertical: 5),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(child: Center(child: Text('${index + 1}'))), 
                      Expanded(child: Center(child: Text(result.participant.bibNumber))), 
                      Expanded(child: Center(child: Text(result.participant.name))),
                      Expanded(child: Center(child: Text(result.race.Time))), 
                      Expanded(child: Center(child: Text(result.finishTime))), 
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
