// lib/stopwatch_provider.dart
// lib/stopwatch_provider.dart
import 'package:flutter/material.dart';
import '../repository/stopwatch_repo.dart'; // Import your StopwatchFunctions class

class StopwatchProvider with ChangeNotifier {
  final StopwatchRepository  stopwatchFunctions;

  StopwatchProvider(this.stopwatchFunctions);

  String displayTime = "00:00:00";
  String stopButtonText = "Stop";
  
  bool _isRunning = false;

  bool get isRunning => _isRunning;

  void updateTime(String time) {
    displayTime = time;
    notifyListeners(); 
  }

  void start() {
    _isRunning = true;
    stopwatchFunctions.start(updateTime);
    notifyListeners();
  }

  void stop() {
    if (stopwatchFunctions.isRunning) {
      stopwatchFunctions.stop();
      stopButtonText = "Continue";
    } else {
      stopwatchFunctions.continueTimer(updateTime);
      stopButtonText = "Stop";
    }
    notifyListeners();
  }

  void reset() {
    stopwatchFunctions.reset(updateTime);
    stopButtonText = "Stop";
    _isRunning = false;
    notifyListeners();
  }
}


