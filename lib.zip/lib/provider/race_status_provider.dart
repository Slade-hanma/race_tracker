import 'package:flutter/material.dart';
import '../repository/race_status_repo.dart';
import '../data/participant_list.dart';

class RaceStatusProvider with ChangeNotifier {
  final RaceStatusRepository _repo;

  RaceStatusProvider(this._repo);

  RaceStatus getStatus(String raceId) => _repo.getStatus(raceId);

  void updateStatus(String raceId, RaceStatus status) {
    _repo.updateStatus(raceId, status);
    notifyListeners();
  }
}