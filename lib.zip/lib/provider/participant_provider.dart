import 'package:flutter/material.dart';
import '../repository/participant_repo.dart';
import '../model/participant_model.dart';

class ParticipantProvider with ChangeNotifier {
  final ParticipantRepository  _repo;
   ParticipantProvider(this._repo);

  List<Participant> get participants => _repo.getParticipants();

  int getNextId(){
    return _repo.getNextId();
  }

  void addParticipant(Participant participant) {
    _repo.addParticipant(participant);
    notifyListeners(); // Notify listeners to update the UI
  }

  void updateParticipant(Participant updatedParticipant) {
    _repo.updateParticipant(updatedParticipant);
    notifyListeners();
  }

  void deleteParticipant(String id) {
    _repo.deleteParticipant(id);
    notifyListeners();
  }
}
