import 'package:flutter/material.dart';
import '../repository/result_repo.dart'; 
import '../model/result_model.dart';

class ResultProvider with ChangeNotifier {
  final ResultRepository  _repo;

  ResultProvider(this._repo);

  List<Result> get results => _repo.getResults();

  void addResult(Result result) {
    _repo.addResult(result);
    notifyListeners(); 
  }
}
