// lib/result_model.dart
import 'participant_model.dart'; 
import 'race_model.dart'; 

class Result {
  final Participant participant; 
  final Race race; 
  final String finishTime; 

  Result({
    required this.participant,
    required this.race,
    required this.finishTime,
  });
}
