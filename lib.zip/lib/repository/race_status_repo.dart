import '../data/participant_list.dart';

abstract class RaceStatusRepository {
  RaceStatus getStatus(String raceId);
  void updateStatus(String raceId, RaceStatus status);
}
