import '../model/result_model.dart';

abstract class ResultRepository {
  List<Result> getResults();
  void addResult(Result result);
}
