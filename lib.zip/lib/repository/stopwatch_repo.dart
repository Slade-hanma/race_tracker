abstract class StopwatchRepository {
  bool get isRunning; 

  void start(Function(String) updateTime);
  void stop();
  void continueTimer(Function(String) updateTime);
  void reset(Function(String) updateTime);
}
