import '../../model/race_model.dart';
import '../../data/participant_list.dart'; // Import the race data
import '../race_repo.dart';

class MockRaceRepo implements RaceRepository{
  final List<Race> _races = races;

  List<Race> getRaces() => List.from(_races);

  void addRace(Race race) {
    _races.add(race);
  }
}
