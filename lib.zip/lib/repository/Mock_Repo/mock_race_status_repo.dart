import '../../data/participant_list.dart';
import '../race_status_repo.dart';


class MockRaceStatusRepo implements RaceStatusRepository{
  final Map<String, RaceStatus> _statuses = {};

  RaceStatus getStatus(String raceId) => _statuses[raceId] ?? RaceStatus.pending;

  void updateStatus(String raceId, RaceStatus status) {
    _statuses[raceId] = status;
  }
}