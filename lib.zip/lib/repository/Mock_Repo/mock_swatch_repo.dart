import 'dart:async';
import '../stopwatch_repo.dart';


class MockSwatchRepo implements StopwatchRepository{
  late Timer timer;
  bool isRunning = false;
  int elapsedMilliseconds = 0;

  void start(Function updateTime) {
    if (!isRunning) {
      isRunning = true;
      timer = Timer.periodic(Duration(milliseconds: 10), (Timer timer) {
        elapsedMilliseconds += 10;
        updateTime(formatDuration(elapsedMilliseconds));
      });
    }
  }

  void stop() {
    if (isRunning) {
      isRunning = false;
      timer.cancel();
    }
  }

  void continueTimer(Function updateTime) {
    if (!isRunning) {
      isRunning = true;
      timer = Timer.periodic(Duration(milliseconds: 10), (Timer timer) {
        elapsedMilliseconds += 10;
        updateTime(formatDuration(elapsedMilliseconds));
      });
    }
  }

  void reset(Function updateTime) {
    stop();
    elapsedMilliseconds = 0;
    updateTime("00:00:00"); // Reset to initial format
  }

  String formatDuration(int milliseconds) {
    final hours = (milliseconds ~/ 3600000).toString().padLeft(2, '0');
    final minutes = ((milliseconds % 3600000) ~/ 60000).toString().padLeft(2, '0');
    final seconds = ((milliseconds % 60000) ~/ 1000).toString().padLeft(2, '0');
    final millis = (milliseconds % 1000 ~/ 10).toString().padLeft(2, '0'); // Get milliseconds
    return "$hours:$minutes:$seconds.$millis"; // Return formatted string
  }
}
