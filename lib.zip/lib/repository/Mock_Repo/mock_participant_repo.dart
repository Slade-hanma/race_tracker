import '../../model/participant_model.dart';
import '../../data/participant_list.dart';
import '../participant_repo.dart';


class MockParticipantRepo implements ParticipantRepository{
  final List<Participant> _participants = participants;
  int _lastId = 0;

  int getNextId() {
    _lastId++;
    return _lastId;
  }

  List<Participant> getParticipants() => List.from(_participants);

  void addParticipant(Participant participant) {
    _lastId++;
    final newParticipant = Participant(
      id: _lastId,
      name: participant.name,
      sex: participant.sex,
      dateOfBirth: participant.dateOfBirth,
      school: participant.school,
      bibNumber: participant.bibNumber,
    );
    _participants.add(newParticipant);
  }

  void updateParticipant(Participant updated) {
    final index = _participants.indexWhere((p) => p.id == updated.id);
    if (index != -1) {
      _participants[index] = updated;
    }
  }

  void deleteParticipant(String id) {
    _participants.removeWhere((p) => p.id == id);
  }
}