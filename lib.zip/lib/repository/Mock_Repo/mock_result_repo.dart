import '../../model/result_model.dart';
import '../../data/participant_list.dart';
import '../result_repo.dart';

class MockResultRepo implements ResultRepository {
  final List<Result> _results = results;

  List<Result> getResults() => List.from(_results);

  void addResult(Result result) {
    _results.add(result);
  }
}
