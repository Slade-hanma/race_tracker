import '../model/race_model.dart';

abstract class RaceRepository {
  List<Race> getRaces();
  void addRace(Race race);
}
