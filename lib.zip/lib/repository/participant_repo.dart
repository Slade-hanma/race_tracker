import '../model/participant_model.dart';

abstract class ParticipantRepository {
  int getNextId();
  List<Participant> getParticipants();
  void addParticipant(Participant participant);
  void updateParticipant(Participant updated);
  void deleteParticipant(String id);
}
